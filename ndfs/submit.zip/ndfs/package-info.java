/**
 * This package provides common classes, exceptions and interfaces for the NDFS
 * programming assignment.
 */
package ndfs;
