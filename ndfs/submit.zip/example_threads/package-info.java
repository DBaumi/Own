/**
 * This package contains an example of using threads.
 */

package example_threads;